package com.example.amstuckshopapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.text.BreakIterator;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class SignIn extends AppCompatActivity{

    TextView tvLogo;
    TextView tvAMSHeading;
    TextView tvSignInText;
    EditText etEmail;
    View etPassword;
    CheckBox cbRemember_me;
    Button bSignIn;
    private BreakIterator Password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        tvLogo =  findViewById(R.id.logo);
        tvAMSHeading = findViewById(R.id.heading);
        tvSignInText = findViewById(R.id.sign_in_heading);
        etEmail = findViewById(R.id.school_email);
        etPassword = findViewById(R.id.password);
        bSignIn = findViewById(R.id.sign_in_btn);
        cbRemember_me = findViewById(R.id.remember_me);



        ClickSignIn();


    }

    //method for operation check sign in
    private void ClickSignIn() {

        bSignIn.setOnClickListener(view -> {

            //Email Validation
            if (etEmail.getText().toString().trim().isEmpty() && Arrays.toString(new String[]{etPassword.toString()}).trim().isEmpty()) {

                Snackbar snackbar = Snackbar.make(view, "Please fill out these fields",
                        Snackbar.LENGTH_LONG);
                View snackView = snackbar.getView();
                snackView.setBackgroundColor(getResources().getColor(R.color.red));
                snackbar.show();
                etEmail.setError("School email should not be empty");
            } else {
                bSignIn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(SignIn.this, homePage.class);
                        startActivity(intent);
                    }
                });

                //Checking email username
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                if(etEmail.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(),"enter email address", Toast.LENGTH_SHORT).show();
                }else {
                    if (etEmail.getText().toString().trim().matches(emailPattern)) {
                        Toast.makeText(getApplicationContext(),"valid email address",Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(),"Invalid email address", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            //Password Validation
            

            if (cbRemember_me.isChecked()) {
                //Here you can write the codes if box is checked
            } else {
                //Here you can write the codes if box is not checked
            }

        });

    }

}